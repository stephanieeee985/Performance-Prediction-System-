# Student Performance Prediction System

A classroom prototype (Data Mining laboratory) that flags students who may need
additional academic support.

## Problem
Academic risk is often noticed only after poor results. This prototype explores
early identification using available student indicators (study time, absences,
past failures, G1, G2, and more).

## Dataset
UCI Machine Learning Repository, *Student Performance* (ID 320):
https://archive.ics.uci.edu/dataset/320/student+performance
Downloaded automatically with `ucimlrepo` and saved as `student_data.csv`.

## Prediction target
`G3 < 10` = **AT RISK** (1); `G3 >= 10` = **NOT AT RISK** (0).
`G3` is used only to build the target and is never an input feature
(to avoid target leakage).

## Technologies
Python 3.10+, pandas, scikit-learn (Random Forest), joblib, Streamlit, Git/GitHub.

## Installation and run
```bash
pip install -r requirements.txt
python train_model.py      # creates student_data.csv and student_model.pkl
streamlit run app.py       # opens http://localhost:8501
```
In the app, download the sample input CSV, upload it, view the predictions, and
download the results.

## Limitations
- Trained on one Portuguese secondary-school dataset; may not generalize to
  other institutions or populations.
- Small dataset; accuracy alone is not enough, so check recall for the at-risk class.
- Predictions are not diagnoses and must not be the sole basis for real
  student decisions.
